package com.example.juro.mymodernartuii;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SeekBar ;
import android.widget.TextView;

public class MainActivity extends Activity {
    // Source: based on http://stackoverflow.com/questions/15326290/get-android-seekbar-value-and-display-it-on-screen
    /** Called when the activity is first created. */

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SeekBar seekBar = ( SeekBar )findViewById(R.id.seekbar);
        final TextView seekBarValue = ( TextView)findViewById(R.id.seekbarvalue);

        final TextView tv1 = (TextView) findViewById(R.id.TextView01);
        final TextView tv2 = (TextView) findViewById(R.id.TextView02);
        final TextView tv3 = (TextView) findViewById(R.id.TextView03);
        final TextView tv4 = (TextView) findViewById(R.id.TextView04);
        final TextView tv5 = (TextView) findViewById(R.id.TextView05);
        final TextView tv6 = (TextView) findViewById(R.id.TextView06);
        final TextView tv7 = (TextView) findViewById(R.id.TextView07);


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                // TODO Auto-generated method stub
                seekBarValue.setText(String.valueOf(progress));

                int colTV1 = interpolateColor(Color.RED, Color.GREEN, seekBar.getProgress() / 50);
                int colTV2 = interpolateColor(Color.rgb(255, 155, 0), Color.BLUE, seekBar.getProgress() / 25);
                int colTV3 = interpolateColor(Color.YELLOW, Color.rgb(238, 130, 238), seekBar.getProgress() / 50);
                int colTV4 = interpolateColor(Color.GREEN, Color.RED, seekBar.getProgress() / 25);
                int colTV5 = interpolateColor(Color.BLUE, Color.rgb(255, 155, 0), seekBar.getProgress() / 50);
                int colTV6 = interpolateColor(Color.rgb(75, 0, 130), Color.rgb(280, 255, 125), seekBar.getProgress() / 25);
                int colTV7 = interpolateColor(Color.rgb(238, 130, 238), Color.YELLOW, seekBar.getProgress() / 50);

                tv1.setBackgroundColor(colTV1);
                tv2.setBackgroundColor(colTV2);
                tv3.setBackgroundColor(colTV3);
                tv4.setBackgroundColor(colTV4);
                tv5.setBackgroundColor(colTV5);
                tv6.setBackgroundColor(colTV6);
                tv7.setBackgroundColor(colTV7);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    //Source: based on http://stackoverflow.com/questions/24055625/android-show-an-alert-dialog-from-the-action-bar
    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        // Handle action bar actions click
        switch (item.getItemId()) {
            case R.id.action_settings:
                new AlertDialog.Builder(this)
                        .setMessage("Artwork inspired by works of Art masters Piet Mondrian and Ben Nicholson.  Click below to see more.")
                        .setCancelable(false)
                        .setNegativeButton("Visit MoMA site", new
                                DialogInterface.OnClickListener () {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //code if yes
                                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.moma.org/m")));
                                    }
                                })
                        .setPositiveButton("Not now",
                                new DialogInterface . OnClickListener () {
                                    public void onClick( DialogInterface dialog, int id) {
                                        finish();
                                    }
                                })
                        .show();
                return true;
            default: return super.onOptionsItemSelected(item);
        }
    }


    //Source: entirely from http://stackoverflow.com/questions/4414673/android-color-between-two-colors-based-on-percentage/7871291#7871291
    private float interpolate( float a, float b, float proportion) {
        return (a + ((b - a) * proportion));
    }

    //Returns an interpoloated color, between <code>a</code> and <code>b<code>
    private int interpolateColor( int a, int b, float proportion) {
        float [] hsva = new float[3];
        float [] hsvb = new float[3];
        Color .colorToHSV(a, hsva);
        Color .colorToHSV(b, hsvb);
        for ( int i = 0; i < 3; i++) {
            hsvb[i] = interpolate(hsva[i], hsvb[i], proportion);
        }
        return Color .HSVToColor (hsvb);
    }

}
