/** Automatically generated file. DO NOT MODIFY */
package com.juro.modernartui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}